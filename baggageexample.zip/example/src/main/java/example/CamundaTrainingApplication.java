package example;



import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("camundatraining")
public class CamundaTrainingApplication extends ServletProcessApplication {
  // empty implementation
}

