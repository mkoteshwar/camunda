package com.bnpparibas.cib.camunda.camundaimpl;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("Camunda-App")
public class CamApplication extends ServletProcessApplication {

}
