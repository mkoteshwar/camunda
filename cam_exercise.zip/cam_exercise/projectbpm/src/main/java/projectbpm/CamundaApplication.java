package projectbpm;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("CamundaApplication")
public class CamundaApplication extends ServletProcessApplication {
	  // empty implementation
}
